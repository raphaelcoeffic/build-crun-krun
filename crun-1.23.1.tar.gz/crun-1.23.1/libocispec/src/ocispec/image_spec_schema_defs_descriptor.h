// Generated from defs-descriptor.json. Do not edit!
#ifndef IMAGE_SPEC_SCHEMA_DEFS_DESCRIPTOR_SCHEMA_H
#define IMAGE_SPEC_SCHEMA_DEFS_DESCRIPTOR_SCHEMA_H

#include <sys/types.h>
#include <stdint.h>
#include "ocispec/json_common.h"
#include "ocispec/image_spec_schema_defs.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

