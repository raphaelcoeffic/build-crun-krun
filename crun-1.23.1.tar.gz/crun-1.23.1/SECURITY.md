## Reporting a Vulnerability

If you discover a potential security issue in this project we ask that
you notify us directly via email to security@oci.run (not affiliated
with opencontainers.org).

Please do **not** create a public issue.
