#[allow(clippy::new_ret_no_self)]
pub mod regs;
pub mod sysreg;
