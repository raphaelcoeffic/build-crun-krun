#[cfg(feature = "amd-sev")]
pub mod amdsnp;

#[cfg(feature = "tdx")]
pub mod inteltdx;
